/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SimpleFormComponent } from './simple-form.component';

describe('Component: SimpleForm', () => {
  it('should create an instance', () => {
    let component = new SimpleFormComponent();
    expect(component).toBeTruthy();
  });
});
